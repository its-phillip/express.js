# 🌸 AgriSmart API

Developed by **Phillip & Phoebe**

AgriSmart API is a simple Express.js project that manages flower products with authentication, middleware, and filtering features.

## 🚀 Features
- RESTful CRUD API for products
- Custom middleware (logger, authentication)
- Error handling
- Filtering, pagination, and search support

## 🧰 Setup

1. Clone the repo  
   ```bash
   git clone <repo-url>
   cd agrismart-api
   ```

2. Install dependencies  
   ```bash
   npm install
   ```

3. Run the server  
   ```bash
   npm start
   ```

4. Test endpoints using Postman or curl.

## 🧩 API Endpoints

| Method | Endpoint | Description |
|--------|-----------|-------------|
| GET | /api/products | Get all products |
| GET | /api/products/:id | Get single product |
| POST | /api/products | Create product |
| PUT | /api/products/:id | Update product |
| DELETE | /api/products/:id | Delete product |

### Example Request

```bash
POST /api/products
Headers: { "Authorization": "secret123" }
Body: { "name": "Lilies", "price": 250 }
```

---

© 2025 AgriSmart — Built by Phillip & Phoebe 🌿
