const express = require('express');
const router = express.Router();

let products = [
  { id: 1, name: 'Roses', price: 200 },
  { id: 2, name: 'Tulips', price: 150 },
];

// Get all products (with filtering, pagination, search)
router.get('/', (req, res) => {
  let result = [...products];
  const { name, minPrice, maxPrice, page = 1, limit = 5 } = req.query;

  if (name) result = result.filter(p => p.name.toLowerCase().includes(name.toLowerCase()));
  if (minPrice) result = result.filter(p => p.price >= +minPrice);
  if (maxPrice) result = result.filter(p => p.price <= +maxPrice);

  const start = (page - 1) * limit;
  const end = page * limit;
  res.json(result.slice(start, end));
});

// Get product by ID
router.get('/:id', (req, res) => {
  const product = products.find(p => p.id == req.params.id);
  product ? res.json(product) : res.status(404).json({ message: 'Not found' });
});

// Create new product
router.post('/', (req, res) => {
  const newProduct = { id: products.length + 1, ...req.body };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

// Update a product
router.put('/:id', (req, res) => {
  const index = products.findIndex(p => p.id == req.params.id);
  if (index !== -1) {
    products[index] = { ...products[index], ...req.body };
    res.json(products[index]);
  } else {
    res.status(404).json({ message: 'Not found' });
  }
});

// Delete a product
router.delete('/:id', (req, res) => {
  products = products.filter(p => p.id != req.params.id);
  res.json({ message: 'Deleted successfully' });
});

module.exports = router;
